/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package voronoi;
 
/**
 *
 * @author Dany
 */
public class Punto {
    private double x,y;
    
    public Punto(){
        this.x = 0;
        this.y = 0;
    }
    
    public Punto(double x, double y){
        this.x = x;
        this.y = y;
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }

    @Override
    public boolean equals(Object obj) {
        return (((Punto)obj).getX()==this.getX())&&(((Punto)obj).getY()==this.getY());
    }
    
    public String toString(){
        return "("+this.getX()+","+this.getY()+")";
    }
    
    public Punto puntoMedio(Punto p){
        Punto pNuevo = new Punto();
        double x = (this.getX() + p.getX()) / 2;
        double y = (this.getY() + p.getY()) / 2;
        pNuevo = new Punto(x,y);
        return pNuevo;
    }
    
    public double[] getYMediatriz(Punto p){
        
        double a = this.getX();
        double b = this.getY();
        double c = p.getX();
        double d = p.getY();
        if (b != d){
            double x = 0;
            double y = ((Math.pow(a, 2) - 2*a*x + Math.pow(b, 2) -Math.pow(c, 2)+2*c*x - Math.pow(d, 2))/(2*(b-d)));
            double x1 = x+10;
            double y1 = ((Math.pow(a, 2) - 2*a*x1 + Math.pow(b, 2) -Math.pow(c, 2)+2*c*x1 - Math.pow(d, 2))/(2*(b-d)));
            return new double[]{x-x1,y-y1};
        }else{
            return new double[]{0,10};
        }
        
    }
    
}
